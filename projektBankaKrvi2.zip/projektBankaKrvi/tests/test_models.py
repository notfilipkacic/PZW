from django.test import TestCase
from main.models import Donacija, DonacijskaKartica, Donator, KrvnaGrupa,Primatelj,SpremnikKrvi, Primanje

################################################################
# radi ali treba dovrsiti
################################################################


class Testmodels(TestCase):

    def setUp(self):
        self.kg1 = KrvnaGrupa.objects.create(
            kg = 'B',
            
        )

        self.kg2 = KrvnaGrupa.objects.create(
            kg = 'A',
            
        )

        self.kg3 = KrvnaGrupa.objects.create(
            kg = '0',
            
        )

        self.donator1 = Donator.objects.create(
            ime = 'Antea',
            prezime = 'Rozic',
            krvna_grupa = self.kg1

        )

        self.donator2 = Donator.objects.create(
            ime = 'Filip',
            prezime = 'Kacic',
            krvna_grupa = self.kg2
        )


        self.primatelj1 = Primatelj.objects.create(
            ime = 'Nadia',
            prezime = 'Vidas',
            krvna_grupa = self.kg3
        )

        self.dk1 = DonacijskaKartica.objects.create(
            donator = self.donator1
        )



    def test_profesor(self):
        self.assertEquals(self.kg1.kg, "B")
        self.assertEquals(self.donator1.ime, "Antea")
        self.assertEquals(self.donator2.ime, "Filip")
        self.assertEquals(self.primatelj1.ime, "Nadia")
        self.assertEquals(self.dk1.donator.ime, "Antea") ## primjetiti dk1.donator.ime !!!!!!!!!!!!
        
        
"""
        self.sk1 = SpremnikKrvi.objects.create( #Direct assignment to the forward side of a many-to-many set is prohibited. Use krvna_grupa.set() instead
            krvna_grupa = self.kg1
        )

        self.donacija1 = Donacija.objects.create(
            vrijeme_transakcije = '20.02.2020'
            donator = self.donator2
            SpremnikKrvi
        )

        self.primanje1 = DonacijskaKartica.objects.create(
            primatelj = self.primatelj1
            spremnik_krvi = self.sk1
        )
  
 """    