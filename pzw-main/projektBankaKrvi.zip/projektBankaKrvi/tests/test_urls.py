from django.test import SimpleTestCase
from django.urls import reverse, resolve
from main.views import hello_world, Mosquito, DonacijeList, KarticeList, DonatoriList, KrvnaGrupaList,PrimateljList,SpremnikKrviList, PrimanjeList

################################################################
# radi skroz
################################################################

class TestUrls(SimpleTestCase):



    def test_izbornik_url_is_resolved(self):
        url = reverse('main:pocetna')

        self.assertEquals(resolve(url).func.view_class, Mosquito)

    def test_donacija_url_is_resolved(self):
        url = reverse('main:donacije')

        self.assertEquals(resolve(url).func.view_class, DonacijeList)

    def test_donacijskakartica_url_is_resolved(self):
        url = reverse('main:donacijskakartica')

        self.assertEquals(resolve(url).func.view_class, KarticeList)
    
    def test_donator_url_is_resolved(self):
        url = reverse('main:donator')

        self.assertEquals(resolve(url).func.view_class, DonatoriList)
    
    def test_krvnagrupa_url_is_resolved(self):
        url = reverse('main:krvnagrupa')

        self.assertEquals(resolve(url).func.view_class, KrvnaGrupaList)
    


    def test_primanje_url_is_resolved(self):
        url = reverse('main:primanje')

        self.assertEquals(resolve(url).func.view_class, PrimanjeList)


    def test_spremnik_krvi_url_is_resolved(self):
        url = reverse('main:spremnikkrvi')

        self.assertEquals(resolve(url).func.view_class, SpremnikKrviList)
        
    def test_primatelj_url_is_resolved(self):
        url = reverse('main:primatelj')

        self.assertEquals(resolve(url).func.view_class, PrimateljList)
"""
    def test_hello_world_url_is_resolved(self):
        url = reverse('main:')
        print(resolve(url))

        self.assertEquals(resolve(url).func, hello_world)


"""