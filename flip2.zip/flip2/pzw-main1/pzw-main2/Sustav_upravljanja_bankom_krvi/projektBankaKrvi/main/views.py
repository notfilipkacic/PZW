from contextlib import _RedirectStream
from django.shortcuts import render
from django.http import HttpResponse

from django.shortcuts import get_object_or_404
from django.views.generic import ListView
from main.models import *

# reg
from django.contrib.auth.forms import UserCreationForm #za registraciju
from django.contrib.auth import authenticate, login, logout

## Create your views here.

def registration(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']

            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('')

    else:
        form = UserCreationForm()

    context = {'form': form}

    return render(request, 'registration/register.html', context)


def logout(request):
    logout(request)
    return redirect('login')

def hello_world(request):
    return HttpResponse('Dodajte u adresu <i>/izbornik</i> za izbornik...! <strong>#inf0gang</strong>')
    # primjetiti korištenje HTML-a

class Mosquito(ListView):
    template_name = 'mosquito.html'

    def get_queryset(self):
        return 0

class DonacijeList(ListView):
    template_name = 'donacije_list.html'

    def get_queryset(self):
        return Donacija.objects.all()

class KarticeList(ListView):
    template_name = 'donacijske_kartice_list.html'

    def get_queryset(self):
        return DonacijskaKartica.objects.all()

class DonatoriList(ListView):
    template_name = 'donator_list.html'

    def get_queryset(self):
        return Donator.objects.all()

class KrvnaGrupaList(ListView):
    template_name = 'krvnagrupa_list.html'

    def get_queryset(self):
        return KrvnaGrupa.objects.all()

class PrimateljList(ListView):
    template_name = 'primatelj_list.html'

    def get_queryset(self):
        return Primatelj.objects.all()

class PrimanjeList(ListView):
    template_name = 'primanja_list.html'

    def get_queryset(self):
        return Primatelj.objects.all()

class SpremnikKrviList(ListView):
    template_name = 'spremnik_list.html'

    def get_queryset(self):
        return SpremnikKrvi.objects.all()