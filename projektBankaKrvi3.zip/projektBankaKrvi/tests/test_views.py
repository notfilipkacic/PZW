from django.test import TestCase, Client
from django.urls import reverse
from main.models import Donacija, DonacijskaKartica, Donator, KrvnaGrupa,Primatelj,SpremnikKrvi, Primanje

################################################################
# radi ali treba dovrsiti
################################################################

class TestViews(TestCase):

    def setUp(self):
        self.client = Client()
        self.homepage_url = reverse('main:pocetna')
        self.donator = reverse('main:donator')
        

        self.kg1 = KrvnaGrupa.objects.create(
            kg = 'B'
        )

        self.donator1 = Donator.objects.create(
            ime = 'TestName',
            prezime = 'TestSurr',
            krvna_grupa = self.kg1,
        )

    def test_project_donator_GET(self):
        client = Client()

        response = client.get(self.donator)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'donator_list.html')
