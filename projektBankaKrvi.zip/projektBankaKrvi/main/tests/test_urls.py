from django.test import SimpleTestCase
from django.urls import reverse, resolve
from main.views import *

class TestUrls(SimpleTestCase):

    def test_hw(self):
        url = reverse('hw')
        print(resolve(url))
        self.assertEquals(resolve(url).func, hello_world)

    def test_homepage(self):
        url = reverse('')
        self.assertEquals(resolve(url).func.view_class, Mosquito)

    def test_donacija(self):
        url = reverse('donacija')
        self.assertEquals(resolve(url).func.view_class, DonacijeList)

    def test_dk(self):
        url = reverse('donacijskakartica')
        self.assertEquals(resolve(url).func.view_class, KarticeList)
    
    def test_donator(self):
        url = reverse('donator')
        self.assertEquals(resolve(url).func.view_class, DonatoriList)
    
    def test_kg(self):
        url = reverse('krvnagrupa')
        self.assertEquals(resolve(url).func.view_class, KrvnaGrupaList)
    
    def test_primatelj(self):
        url = reverse('primatelj')
        self.assertEquals(resolve(url).func.view_class, PrimateljList)

    def test_sk(self):
        url = reverse('spremnikkrvi')
        self.assertEquals(resolve(url).func.view_class, SpremnikKrviList)

    def test_primanje(self):
        url = reverse('primanje')
        self.assertEquals(resolve(url).func.view_class, PrimanjeList)