from django.urls import path
from . import views

app_name = 'main'  # here for namespacing of urls.

urlpatterns = [
    #path('register', views.register_request, name='register'),
    path('main/register/', views.register, name='register'),
    path('logout/', views.logout, name='logout'),
    path('donacija', views.DonacijeList.as_view(), name='donacije'), # ne radi jer je primary
    path('donacijskakartica', views.KarticeList.as_view(), name='donacijskakartica'), # ne radi jer je primary
    path('donator', views.DonatoriList.as_view(), name='donator'),
    path('krvnagrupa', views.KrvnaGrupaList.as_view(), name='krvnagrupa'),
    path('primatelj', views.PrimateljList.as_view(), name='primatelj'),
    path('spremnikkrvi', views.SpremnikKrviList.as_view(), name='spremnikkrvi'), # ne radi jer je primary
    path('primanje', views.PrimanjeList.as_view(), name='primanje'), # ne radi jer je m2m veza
    path('', views.Mosquito.as_view(), name='pocetna'),
   # path('hi', views.hello_world, name='Hello world!'),

    path('pretragadonator/', views.pretragadonator, name = 'pretragadonator'),
    path('pretraga_primatelj', views.pretraga_primatelj, name='pretragaprimatelj'),
    path('dodajdonator', views.dodaj_donator, name='dodajdonator'),
    path('dodajprimatelj', views.dodaj_primatelj, name='dodajprimatelj'),
    
    path('delete_donator/<int:donator_id>', views.delete_donator, name='delete_donator'),
    path('delete_primatelj/<int:primatelj_id>', views.delete_primatelj, name='delete_primatelj'),

    path('update_donator/<int:donator_id>', views.update_donator, name='update_donator'),
    path('update_primatelj/<int:primatelj_id>', views.update_primatelj, name='update_primatelj'),
]